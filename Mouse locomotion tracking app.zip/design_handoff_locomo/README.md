# Handoff: Locomo — Mouse Locomotion Tracking App

## Overview
Locomo is a research tool for behavioral neuroscience labs to upload rodent locomotion videos, define ROIs (regions of interest) and pixel-to-cm calibration, run a tracking pipeline, and review distance/speed/ROI-occupancy metrics per video, per batch, and per subject. This package documents the full designed flow: experiment creation wizard, experiment results (3 views), a dataset library, a video-level analysis/replay tool, and pipeline configuration.

## About the Design Files
The files in this bundle (`Locomo.dc.html`) are **design references built as a single HTML/JS prototype** — they show intended layout, copy, states, and interaction behavior. They are **not production code to copy directly**. The task is to **recreate this design in the target codebase's existing frontend stack** (React, Vue, etc.) using its established component library, state management, and data-fetching patterns — or, if no frontend exists yet, choose the framework that best fits the backend/stack and implement the designs there.

All data in the prototype (experiments, videos, per-subject metrics, speed curves, heatmaps) is **mocked/hardcoded in the component's JS** — every list, chart, and stat needs to be wired to real backend endpoints.

## Fidelity
**High-fidelity** for visual design (colors, type, spacing, card/table layouts) — recreate pixel-close using the target codebase's design system if one exists, otherwise match the values in this doc.
**Low/medium-fidelity** for the interactive mechanics added late in the process (ROI drawing, trajectory replay, playback) — these are illustrative mockups of the *interaction concept*, not functioning computer-vision or video-scrubbing implementations. The real ROI editor should draw over actual video frames; the trajectory replay should read real per-frame position data instead of a seeded-random path.

## Global layout
- Fixed left sidebar (248px, dark `#1a212e` background, `#cbd2dc` text) with workspace switcher, 4 nav items (Experiments / Datasets / Analyses / Pipeline settings), user footer.
- Main column: sticky topbar (58px, translucent `rgba(243,244,246,.82)` blur) with breadcrumb (section label / current item) + search box + notification icon, then screen content scrolling below, `max-width` 980–1240px centered depending on screen.
- Fonts: **Inter** (UI text) + **JetBrains Mono** (all numeric/data/file values — distances, speeds, timestamps, filenames, code-like labels). Load both from Google Fonts, weights 400/500/600/700 (Inter) and 400/500/600 (JetBrains Mono).
- Palette: near-white/gray background `#f3f4f6`, white `#fff` cards, border `#e7e9ee`/`#e5e7eb`, text `#0f1729` (primary) / `#344054` (secondary) / `#667085`, `#8a93a3`, `#98a2b3` (tertiary/labels, descending emphasis). **Brand accent `#CC5500`** (burnt orange) used for primary actions, active states, and the one "Done/Analyzed" status pill. Status colors: processing `#475467` on `#eef1f4`, pending `#667085` on `#f2f4f7`. Group colors: Saline `#2563eb` on `#eef3fe`, CNO `#059669` on `#f0fdf6`.
- Card style: `border-radius: 12–13px`, `border: 1px solid #e7e9ee`, `box-shadow: 0 1px 2px rgba(16,24,40,.04)`, padding 18–22px.
- Border radius scale: 6–9px (buttons/pills/inputs), 11–14px (cards), 20px (status pills/chips).

## Screens / Views

### 1. Experiments — List (`isList` / screen `list`)
**Purpose:** browse all experiments, filter by status, search, jump into one, or start a new one.
- Header row: "Experiments" h1 (24px/700) + count line, and a primary **New Experiment** button (`#CC5500` bg, white text, plus icon) — opens the New Experiment wizard.
- Filter bar: search input (left, filters by name/subject) + segmented status-tab control (All / Done / Processing / Pending) right-aligned, white pill container.
- List: one row per experiment — icon tile, name + subject (mono) + apparatus, video count, created date (mono), status pill (Done=orange dot/bg, Processing=spinning ring, Pending=gray dot), chevron. Hover: border darkens, shadow lifts, `translateY(-1px)`.
- Empty state: dashed icon illustration, title/body copy driven by whether a filter is active, "Create your first experiment" CTA.

### 2. New Experiment wizard (3 steps — screens `new-upload` / `new-roi` / `new-review`)
Replaces the old "no-op New Experiment button." A linear 3-step flow, each step shows a small "New experiment · Step N of 3" eyebrow above an `h1`.

**Step 1 — Upload** (`new-upload`, max-width 760px)
- Mode toggle pill group: "Single video" / "Batch" (dark pill = active). Switching to Single truncates any existing multi-selection to 1 file.
- Native `<input type="file" accept="video/*" multiple>` wrapped in a large dashed dropzone (`border:2px dashed`, hover turns accent-orange border + tint bg). Copy: "Arraste vídeos aqui, ou navegue" / MP4·AVI·MOV up to 4GB.
- Selected-files list: white bordered rows, filename (mono) + size + remove (✕) button.
- Footer: Cancel (back to list) / Continue → Step 2 (disabled if no files — in the real build, disable the button rather than no-op).

**Step 2 — ROI & calibration** (`new-roi`, max-width 1180px)
- Key concept: **ROI reference and calibration reference are independent per video.** Any video can become a "reference" for ROI, for calibration, or both; every other video points ("inherits") at exactly one reference video per dimension. This supports batches mixing multiple physical circuits and/or camera angles (e.g. same camera reused across circuits → own ROI, shared calibration).
- Left: dark canvas card (`#11161f` bg) previewing the *currently active* video with an illustrative dashed ROI overlay, plus two pill buttons: "★ usar como referência de ROI" / "★ usar como referência de calibração" — clicking marks the active video as self-referencing for that dimension.
- Right: vertical list of every video in the batch. Each row is clickable (sets it "active" → shown in canvas) and shows two inline labels, "ROI: …" and "Cal: …" — either "★ referência" (orange, non-interactive) if this video is a reference for that dimension, or "herda de <filename>" (gray, clickable) which **cycles** through all current reference videos for that dimension when clicked.
- Footer: Back / Continue → Step 3.

**Step 3 — Review & create** (`new-review`, max-width 820px)
- Experiment name text input (placeholder = first filename without extension).
- Table: one row per video — filename (mono), an editable Subject-ID text input, resolved ROI source label, resolved calibration source label.
- Footer: Back / "Criar experimento ✓" (`#CC5500`) — creates the experiment record and routes to the Experiment Detail screen with all its videos in a `processing` state.

### 3. Experiment Detail / Upload (`isDetail`, screen `detail`)
**Purpose:** the experiment's home — metadata, subject chips, per-video list with status + actions, and a dropzone to add more videos later.
- Back link, title + "Active" status pill, description, "Edit details" button.
- 4-column meta strip (bordered grid, 1px dividers) for key/value facts (apparatus, arena size, etc.).
- Subject chips row (colored dot + subject ID + Saline/CNO group tag).
- "Videos" section header with analyzed-count + **Compare subjects** button (→ Compare screen).
- Video rows: thumbnail tile (dark diagonal-stripe placeholder + play triangle), subject dot + filename (mono), subject/group/meta line, status (Analyzed pill + "View results" button, or spinning Processing + "View progress" button).
- Bottom dropzone (same visual language as wizard Step 1) to add more videos to this existing experiment.

### 4. Processing (`isProcessing`, screen `processing`)
**Purpose:** live pipeline status for one video.
- Progress card: pulsing dot + "Processing video" + filename, giant % counter (mono, orange), animated gradient progress bar with a diagonal shimmer sweep, stage/frame + elapsed/eta line.
- Two-column: (a) Pipeline step list (done=check in orange circle, running=spinning ring, queued=empty ring) with per-step note; (b) dark "Worker output" console with monospace log lines (older lines dim, current line highlighted + blinking cursor).
- This should be driven by real job/queue status (e.g. polling or websocket), not a static mock.

### 5. Experiment Results (`isResults`, screen `results`) — **3-tab structure**
**Purpose:** the analysis output for a completed experiment. Reorganized (per stakeholder request) into three explicit views, all reachable from one segmented tab control under the header:
- **Por vídeo** ("video" tab) — single-video deep dive. Shows a subject/group filter chip row (Todos/Saline/CNO) above a video-picker pill bar (colored dot + subject ID + group tag); picking a video/filtering re-renders: 4 big stat cards (Distance, Mean speed, Median speed, Time-in-ROI-center), a 2-col row of occupancy-heatmap canvas + speed-profile SVG line chart, and a "Time in ROI zones" table (zone, time, share-of-session bar, entries, mean speed).
- **Média da batch** ("batch" tab, default landing tab) — cohort overview. 2-col grid of metric cards, each showing cohort mean + SD and a 2-row bar comparison between the two treatment groups; below, a 3-up small-multiple of per-subject occupancy heatmaps and an overlaid multi-subject speed-profile chart.
- **Por subject** ("subject" tab) — a metrics-by-subject table: one column per subject (colored dot + ID + group tag), one row per metric, best value per row highlighted (tinted cell + orange number). Includes a "Ver comparação completa" button that deep-links to the full standalone Compare screen for subject (de)selection and overlaid speed charts.
- Header also carries Export CSV / Download Report actions (not yet wired to anything real).

### 6. Compare subjects (`isCompare`, screen `compare`)
Full-page subject comparison: toggle chips to include/exclude subjects (min 2), a metrics table with per-column best-value highlighting, and an overlaid speed-profile SVG chart with a legend. Reachable from the Detail screen and from the Results→"Por subject" tab.

### 7. Datasets (`isDatasets`, screen `datasets`)
**Purpose:** library of every uploaded video across experiments, for reuse.
- Header + "Upload video" button.
- Table: checkbox, filename, subject, duration·fps, size, calibration status (calibrated → px/cm value; uncalibrated → gray "Not calibrated" dot+label), "Used in" experiment count.
- *Not yet implemented but described by stakeholder*: multi-select rows → "use in new experiment" batch action, feeding the New Experiment wizard's video list directly from previously-uploaded, already-tracked videos instead of only fresh uploads.

### 8. Analyses (`isAnalyses`, screen `analyses`) — video deep-dive / trajectory replay
This **replaces** an earlier "reusable ROI/metric preset editor" concept — the stakeholder decided Analyses should instead be a per-video inspection tool.
- Two native `<select>` dropdowns at the top: **Experimento** (all completed experiments) and **Vídeo** (that experiment's completed videos, labeled by filename). Changing experiment resets the video selection.
- Left: "Trajectory replay" card — dark canvas SVG showing togglable ROI overlays (circle/ring/rect shapes, each with its own color) and a polyline trace of the animal's path revealed progressively by a `frame %` state value, plus a filled dot at the current position. Header shows frame count "N / 9,000 fr" and elapsed seconds.
  - Playback controls: play/pause circular button, a native `<input type="range">` scrubber (0–100%) bound to frame position, and a 1×/4×/8× speed segmented control. Play starts a `setInterval` that advances the frame percentage; **must be stopped when the user navigates away from this screen** (the prototype had a real bug here — a duplicate navigation method let the timer keep firing after leaving the screen; make sure the real implementation ties the timer's lifecycle to this view actually being mounted/visible, not just to a "playing" boolean).
- Below (full width): a responsive metrics grid (`repeat(auto-fit,minmax(140px,1fr))`) — one card per computed metric (distance, mean/median speed, time-in-ROI, entries, thigmotaxis) for the selected video.
- Right column: "ROIs visíveis" checklist (toggle each ROI's visibility on the canvas) and a small "Vídeo" info card (subject/group/file/meta).
- **Real implementation note:** the trajectory here is a deterministically-seeded fake random walk, and ROI shapes are fixed illustrative geometry. In production this needs (a) real per-frame X/Y centroid data from the tracking pipeline, (b) the actual ROI polygons/circles defined for that video's experiment, and ideally (c) the source video frame as a background rather than a plain dark canvas.

### 9. Pipeline settings (`isSettings`, screen `settings`)
**Purpose:** global tracking/worker defaults (calibration was intentionally moved out of here into the New Experiment wizard, since calibration is per-video/per-reference, not global).
- "Tracking" card: detector model selector (display-only chip), confidence-threshold slider (display-only), "Interpolate dropped frames" toggle.
- "Cinemática" card: 3-up grid (smoothing window, speed-outlier clamp, min bout duration).
- "Workers e fila" card: live-jobs pill, 3-up grid (concurrency segmented control, avg throughput, queue depth).
- Dark "Trecho para Métodos" card: auto-generated Methods-section paragraph (monospace) + Copy button — should be regenerated from the real current settings values.
- **All copy on this screen is in Portuguese** per stakeholder request; every other screen in the app is in English — carry that inconsistency forward intentionally unless the target app standardizes on one language.

## Interactions & Behavior summary
- Navigation is a single `screen` state enum; every screen is conditionally rendered, not routed via URL — recreate with real client-side routing in production (each screen should probably get its own route/URL for deep-linking, browser back/forward, and shareable links to a specific experiment/video).
- Hover states throughout: subtle background tint or border-color shift, no scale/shadow tricks except the Experiments-list-row lift.
- All progress bars, spinners, and the processing-screen log are animated via CSS `@keyframes` (`spin`, `pulse`, `shimmer`, `blink`) — reuse the same easing/durations (`spin .8s linear infinite`, `pulse 1.4s ease-in-out infinite`, `shimmer 1.6s linear infinite`, `blink 1s step-end infinite`).
- The Analyses playback timer is the one piece of "real" client-side interval logic in the prototype — everything else is static/derived from state, no timers.

## State Management (as prototyped — re-derive properly against real data in production)
- `screen`: current view enum.
- `selExp` / `selSubject`: current experiment / current video-or-'all' within Results.
- `resTab` ('video'|'batch'|'subject') + `resGroupFilter` ('all'|'Saline'|'CNO'): Results screen tab + subject filter.
- `wizard`: `{ mode, files[], perVideo: {id:{roiRef,calRef}}, activeVideo, subjects: {id:name}, name }` — New Experiment wizard working state, discarded/reset on cancel or completion.
- `anaExp` / `anaVideo` / `anaFrame` / `anaPlaying` / `anaSpeed` / `anaRois`: Analyses screen selection + playback state.
- `statusFilter` / `query`: Experiments list filters.
- `compSel`: which subjects are checked in the Compare screen (min 2 enforced).
In production, all of the above except pure-UI state (open dropdowns, which tab, playback position) should be backed by real API calls (experiment list, video list, per-video/per-subject metrics, job status polling).

## Design Tokens
- **Colors:** bg `#f3f4f6`; card `#fff`; border `#e7e9ee` / `#e5e7eb` / `#f4f5f7` (hairline); text `#0f1729`, `#1f2937`, `#344054`, `#475467`, `#667085`, `#8a93a3`, `#98a2b3`, `#b0b7c1`, `#cbd2dc`, `#d4d8df`; sidebar `#1a212e` / `#0f1729` (hover) / `#2b3444` / `#7e8794`; accent `#CC5500` / hover `#b34a00` / tint bg `#fbeee4` / darker text-on-tint `#b34a00`; group blue `#2563eb`/`#eef3fe`, group green `#059669`/`#f0fdf6`; heatmap viridis stops `#440154 → #3b528b → #21918c → #5ec962 → #fde725`.
- **Typography:** Inter 400/500/600/700 for UI; JetBrains Mono 400/500/600 for all data/numeric/filename/code text. Scale: 24px/700 (page h1), 23px/700 (detail h1), 17px/700, 15px/700, 14px/700 (card titles), 13–13.5px/500–600 (body/buttons), 12–12.5px (secondary), 11–11.5px (tertiary), 10–10.5px/600 uppercase+letterspaced (eyebrow labels), 38px/600 mono (big stat numbers).
- **Radius:** 6–9px controls, 11–14px cards, 20px pills/status chips, 50% circles/avatars/dots.
- **Shadow:** `0 1px 2px rgba(16,24,40,.04)` (cards), `0 1px 2px rgba(204,85,0,.3)` (primary button), `0 4px 14px rgba(16,24,40,.07)` (hovered list row).

## Assets
No external image/icon assets — all icons are small hand-authored inline SVGs (stroke-based, 14–20px). No illustrations beyond the empty-state dashed-line sketch. Recreate icons with the target codebase's icon library (e.g. Lucide/Heroicons) matching stroke weight ~1.6–1.8px, or keep the inline SVGs if no icon system exists yet.

## Files
- `Locomo.dc.html` — the complete prototype (single file, inline styles, one component class holding all state/derivations). Read the whole file for exact markup/values; this README summarizes it but the file is the source of truth for pixel values and copy text.
